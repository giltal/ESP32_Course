/*
 General graphics lib to be inherited
*/

#ifndef GRAPHICS_h
#define GRAPHICS_h

#include "Fonts/fonts.h"
#include <sys/types.h>
#include <freertos/FreeRTOS.h>
#include <driver/gpio.h>
#include <driver/periph_ctrl.h>
#include <rom/gpio.h>
#include <soc/gpio_sig_map.h>
#include <driver/i2s.h>
#include <rom/lldesc.h>
#include <cstring>

typedef enum { noTrigger = 0, onRiseContinuous = 1, onFailContinuous = 2, onRiseOnce = 3, onFailOnce = 4 }
triggerOption;

typedef void(*_drawPixel)(short x, short y);
typedef void(*_fillScr)(unsigned char r, unsigned char g, unsigned char b);
typedef void(*_drawHLine)(short x, short y, int l);
typedef void(*_drawVLine)(short x, short y, int l);
typedef void(*_setColor)(unsigned char r, unsigned char g, unsigned char b);
typedef void(*_setBackColor)(unsigned char r, unsigned char g, unsigned char b);

class graphics
{
	protected:
		unsigned char	fgColor[3], bgColor[3];
		int				_fgColor, _bgColor;
		unsigned short	fg565, bg565;
		short			maxX, maxY;
		customFont *	currentFonts;
		fontType		fontTypeLoaded;

		void	swap(short * a, short * b);

	public:
		graphics(short maxX, short maxY);
		~graphics() {};
		
		virtual void drawPixel(short x, short y) = 0;
		virtual void fillScr(unsigned char r, unsigned char g,unsigned char b) = 0;
		//_drawPixel drawPixel;
		//_fillScr fillScr;
		virtual void drawLine(short x1, short y1, short x2, short y2);
		virtual void drawHLine(short x, short y, int l);
		virtual void drawVLine(short x, short y, int l);
		
		virtual void setColor(unsigned char r, unsigned char g, unsigned char b);
		virtual void setBackColor(unsigned char r, unsigned char g,unsigned char b);
		virtual unsigned short rgbTo565(unsigned char r, unsigned char g, unsigned char b);
		
		virtual int	getXSize() { return maxX; }
		virtual int	getYSize() { return maxY; }

		virtual void drawRect(short x1, short y1, short x2, short y2,bool fill = false);
		void	drawRoundRect(short x1, short y1, short x2, short y2,bool fill = false);
		void	drawCircle(short x, short y, int radius, bool fill = false);
		void	drawTriangle(short x0, short y0, short x1, short y1, short x2, short y2, bool fill = false);
		void	loadFonts(fontType fontsToLoad);
		short	getFontHieght();
		short	getPrintWidth(char * string);
		void	print(char * string, short x, short y,bool center = false);
};

#define LCD_COMMAND	0
#define LCD_DATA	1

#define SELECT_DATA_COMM(X)		digitalWrite(_cmdDataPin, X);
#define LCD_WRITE_DATA8(VAL)	SPI.writeBYTE((char)VAL);
#define LCD_WRITE_DATA16(X)		SPI.writeShort(X);
#define LCD_WRITE_DATA32(X)		SPI.writeRGB(X);

#define LCD_WRITE_COM(VAL)\
			SELECT_DATA_COMM(LCD_COMMAND);\
			LCD_WRITE_DATA8((char)VAL);\
			SELECT_DATA_COMM(LCD_DATA);

class lcdHwAccessor
{
public:
	lcdHwAccessor() {};
	~lcdHwAccessor() {};
	virtual void setup() = 0;
	virtual void reset() = 0;
	virtual void assertCS() = 0;
	virtual void deAssertCS() = 0;
	virtual void backLightOn() = 0;
	virtual void backLightOff() = 0;
};
// Implementation example:
/*
class lcdAccessor : public lcdHwAccessor
{
public:
	lcdAccessor() {};
	~lcdAccessor() {};
	void setup()
	{
		pcf8574.pinMode(P0, OUTPUT); // Chip Select
		pcf8574.pinMode(P1, OUTPUT); // reset
	}
	void reset()
	{
		pcf8574.digitalWrite(P1, LOW);
		delay(250);
		pcf8574.digitalWrite(P1, HIGH);
		delay(250);
	};
	void assertCS()
	{
		pcf8574.digitalWrite(P0, LOW);
	}
	void deAssertCS()
	{
		pcf8574.digitalWrite(P0, HIGH);
	}
	void backLightOn()
	{

	}
	void backLightOff()
	{

	}
} myLCD_Accessor;*/

#define ST7789_X_OFFSET				52
#define ST7789_Y_OFFSET				40

enum ST77XXres { _135x240, _240x135, _320x240, _480x320 };

enum flipOption { noflip = 0, flipX = 1, flipY = 2, flipXY = 3 };
// ILI9341 as well
class ST77XX : public graphics
{
private:
	unsigned short Xoffset, Yoffset;
	ST77XXres _res;
protected:
	unsigned short colorTable[8];

public:
	ST77XX(ST77XXres res) : graphics(0,0)
	{
		colorTable[0] = rgbTo565(0, 0, 0);
		colorTable[1] = rgbTo565(0, 0, 0xff);
		colorTable[2] = rgbTo565(0, 0xff, 0);
		colorTable[3] = rgbTo565(0, 0xff, 0xff);
		colorTable[4] = rgbTo565(0xff, 0, 0);
		colorTable[5] = rgbTo565(0xff, 0, 0xff);
		colorTable[6] = rgbTo565(0xff, 0xff, 0);
		colorTable[7] = rgbTo565(0xff, 0xff, 0xff);

		_res = res;
		if (res == _135x240)
		{
			maxX = 135;
			maxY = 240;
			Xoffset = ST7789_X_OFFSET;
			Yoffset = ST7789_Y_OFFSET;
		}
		if (res == _240x135)
		{
			maxY = 135;
			maxX = 240;
			Xoffset = ST7789_Y_OFFSET;
			Yoffset = ST7789_X_OFFSET;
		}
		if (res == _320x240)
		{
			maxX = 320;
			maxY = 240;
			Xoffset = 0;
			Yoffset = 0;
		}
		if (res == _480x320)
		{
			maxX = 480;
			maxY = 320;
			Xoffset = 0;
			Yoffset = 0;
		}

	};
	~ST77XX() {};
	void setXY(short x1, short y1, short x2, short y2);
	void setXY(short x, short y);
	void init(unsigned char cmdDataPin, unsigned char mosiPin, unsigned char clockPin, lcdHwAccessor * lcdHwAcc,unsigned int freq = 40000000L);
	virtual void drawPixel(short x, short y);
	virtual void fillScr(unsigned char r, unsigned char g, unsigned char b);
	virtual void drawHLine(short x, short y, int l);
	virtual void drawVLine(short x, short y, int l);
	void draw8bBitMap(short x, short y, const unsigned char * dataArray, bool useSkipBit, flipOption flipOpt = noflip);
	void drawCompressed24bitBitmap(short x, short y, const unsigned int * dataArray);
};

class ST77XX_FB : public ST77XX
{
private:
	unsigned short * frameBuffer;
public:
	ST77XX_FB() : ST77XX(_240x135){}; // only 240x135 is supported in this mode
	~ST77XX_FB();
	bool init(unsigned char cmdDataPin, unsigned char mosiPin, unsigned char clockPin, lcdHwAccessor * lcdHwAcc, unsigned int freq = 40000000L);
	void drawPixel(short x, short y);
	void fillScr(unsigned char r, unsigned char g, unsigned char b);
	void drawHLine(short x, short y, int l);
	void drawVLine(short x, short y, int l);
	void flushFB();
	void draw8bBitMap(short x, short y, const unsigned char * dataArray, bool useSkipBit, flipOption flipOpt = noflip);
	void drawCompressed24bitBitmap(short x, short y, const unsigned int * dataArray);
};

/********** ILI9488 8/9 bit parallel **********/

#define PAR_IOs_MASK	(0x020CF034)
#define GET_RGB666_H(R,G,B)\
		((((unsigned int)G >> 5) & 0x7) | (((unsigned int)R << 1) & 0x1F8))
#define GET_RGB666_L(R,G,B)\
		((((unsigned int)B >> 2) & 0x3f) | (((unsigned int)G << 4) & 0x1c0))
#define GET_RGB565_H(R,G,B)\
		(((G >> 5) & 0x7) | (R & 0xf8))
#define GET_RGB565_L(R,G,B)\
		(((B >> 3)) | ((G << 3) & 0xe0))

#define ILI9488P_MAP_9BIT(X)\
	((0x000C0000 & ((unsigned int)(X) << 12)) | (0x0000F000 & ((unsigned int)(X) << 10)) | (0x00000030 & ((unsigned int)(X) << 4)) | (0x2000000 & ((unsigned int)(X) << 17)) | 0x4)
#define ILI9488P_MAP_8BIT(X)\
	((0x000C0000 & ((unsigned int)(X) << 12)) | (0x0000F000 & ((unsigned int)(X) << 10)) | (0x00000030 & ((unsigned int)(X) << 4)) | 0x4)

enum ParaBusFreq { _8MHz = 10, _10MHz = 8, _12_5MHz = 6, _16MHz = 5, _20MHz = 4, _26MHz = 3 };

typedef struct _I2Ssetup
{
	unsigned int	port;
	unsigned char	dataPins[8];
	unsigned char	clockPin;
	ParaBusFreq		freq;
} I2Ssetup;

#define I2S0_REG_BASE	0x3FF4F000
#define I2S1_REG_BASE	0x3FF6D000

class ILI9488_9BIT_PARALLEL : public graphics
{
private:
	void fifo_reset(i2s_dev_t* dev);
	void dev_reset(i2s_dev_t* dev);
	i2s_port_t port;
	i2s_dev_t* I2S[I2S_NUM_MAX] = { &I2S0, &I2S1 };
	unsigned int i2sRegBase = I2S0_REG_BASE;
	i2s_dev_t* dev;
	unsigned char pinList[9];
	volatile int iomux_signal_base;
	volatile int iomux_clock;
protected:
	unsigned int bCh, bCl;
	bool _9bitFlag = false, paraBusEnabled = false, initialized = false;
public:
	ILI9488_9BIT_PARALLEL(short maxX, short maxY) : graphics(maxX, maxY) {};
	~ILI9488_9BIT_PARALLEL() {};

	void setXY(short x1, short y1, short x2, short y2);
	void setXY(short x, short y);
	void init(bool _9bit = false);
	void drawPixel(short x, short y);
	void fillScr(unsigned char r,unsigned char g,unsigned char b);
	void setColor(unsigned char r, unsigned char g, unsigned char b);
	void drawHLine(short x, short y, int l);
	void drawVLine(short x, short y, int l);
	void drawCompressed24bitBitmap(short x, short y, const unsigned int * dataArray);
	void drawCompressedGrayScaleBitmap(short x, short y, const unsigned short * dataArray, bool invert = false);
	void drawBuffer565(short x, short y, short w, short h, const unsigned short * dataArray);
	bool initI2Sparallel(I2Ssetup * i2sSetup);
	void disableI2Sparallel();
	bool restartI2Sparallel();
	bool parallelStartDMA(lldesc_t* dma_descriptor);
	bool parallelIsDMAactiv();
	bool parallelFIFOwriteWord(unsigned int data);
};

#define DRAW_PIXEL(x,y)\
	drawPixel(x,y)

#define ESP_WRITE_REG(REG,DATA) (*((volatile unsigned int *)(((REG)))) = DATA )
#define ESP_READ_REG(REG) (*((volatile unsigned int *)(((REG)))))

/* 0 for maker's platform , 32 for Smart Home board, 27 for LilyPI*/

/* LCD Chip Select - Alwayes inserted */
/* LCD and Touch pannel reset */

#define ILI9488_8COLORS		0
#define ILI9488_262KCOLORS	1
enum ili9488_mode { rgb111 = ILI9488_8COLORS, rgb666 = ILI9488_262KCOLORS };
enum iliType {ili9488 = 0,ili9481 = 1,ili9341 = 2};

class ILI9488SPI_BASE : public graphics
{
protected:
	void _init(unsigned char cmdDataPin, unsigned char mosiPin, unsigned char clockPin, lcdHwAccessor * lcdHwAcc, unsigned int freq = 40000000L, iliType iliCntrlType = ili9488, 
		       ili9488_mode mode = rgb666);
public:
	ILI9488SPI_BASE(short maxX, short maxY) : graphics(maxX, maxY) {};
	~ILI9488SPI_BASE() {};

	void setXY(short x1, short y1, short x2, short y2);
	void setXY(short x, short y);
};

class ILI9488SPI_262KC : public ILI9488SPI_BASE
{
public:
	ILI9488SPI_262KC(short maxX, short maxY) : ILI9488SPI_BASE(maxX, maxY) {};
	~ILI9488SPI_262KC() {};
	void init(unsigned char cmdDataPin, unsigned char mosiPin, unsigned char clockPin, lcdHwAccessor * lcdHwAcc, unsigned int freq = 40000000L, iliType = ili9488);
	inline void drawPixel(short x, short y);
	void fillScr(unsigned char r, unsigned char g,unsigned char b);
	void drawHLine(short x, short y, int l);
	void drawVLine(short x, short y, int l);
	void drawRect(short x1, short y1, short x2, short y2, bool fill = false);
	void drawCompressed24bitBitmap(short x, short y, const unsigned int * dataArray);
	void drawCompressedGrayScaleBitmap(short x, short y, const unsigned short * dataArray, bool invert = false);
	void drawHebStringUTF8(short x, short y, const char * str, bool swapString, bool invert = false);
	int	 getStringWidth(const char * str);
	void testFunc();
};

typedef enum { singleFrameBuffer = 0, dualFrameBuffers = 1, directMode = 3 }
ili9488_8C_mode;

class ILI9488SPI_8C : public ILI9488SPI_BASE
{
private:
	unsigned char *	frameBuffers[2];
	unsigned int	currentFrameBufferIndex;
	ili9488_8C_mode	workingMode;
	unsigned char fgColorH, fgColorL, bgColorH, bgColorL,fgColorHL;
	bool FGbitOn;

public:
	ILI9488SPI_8C(short maxX, short maxY) : ILI9488SPI_BASE(maxX, maxY) {};
	~ILI9488SPI_8C() {};
	bool init(unsigned char cmdDataPin, unsigned char mosiPin, unsigned char clockPin, lcdHwAccessor * lcdHwAcc, unsigned int freq = 40000000L,
			  ili9488_8C_mode mode = singleFrameBuffer);
	void setColor(unsigned char r, unsigned char g,unsigned char b);
	void setBackColor(unsigned char r, unsigned char g,unsigned char b);
	void setFGbitOn() { FGbitOn = true; }; // All Pixels being drawn will be marked as foreground 
	void setFGbitOff() { FGbitOn = false; };

	inline void drawPixel(short x, short y);
	inline void drawPixel(short x, short y, unsigned char color);
	inline bool isFGbitSet(short x, short y);
	void fillScr(unsigned char r, unsigned char g,unsigned char b);
	void drawHLine(short x, short y, int l);
	bool drawBitmap(short x, short y, const unsigned char * dataArray, bool useSkipBit, flipOption flipOpt = noflip);
	void flushFrameBuffer();
};

class TVout : public graphics
{
private:
	// I2S related
	void fifo_reset(i2s_dev_t* dev);
	void dev_reset(i2s_dev_t* dev);
	i2s_port_t port;
	i2s_dev_t* I2S[I2S_NUM_MAX] = { &I2S0, &I2S1 };
	unsigned int i2sRegBase = I2S0_REG_BASE;
	i2s_dev_t* dev;
	unsigned char pinList[9];
	volatile int iomux_signal_base;
	volatile int iomux_clock;

	unsigned char **displayFrame; // uint8_t * *
	unsigned char paletteIndex = 0;
	unsigned char bgPaletteIndex = 0;
	bool		  doubleBufferOn = false;
	bool		  par9488set = false; // Else ILI9488 8 bit parallel
	unsigned char computeIndex(unsigned char r, unsigned char g, unsigned char b);
public:
	TVout(unsigned short maxX = 320, unsigned short maxY = 269) : graphics(maxX, maxY) {};
	~TVout() {};
	bool init(unsigned char cmdDataPin, lcdHwAccessor * lcdHwAcc, bool doubleBuffer = false, bool par9488 = false, I2Ssetup * i2sSetup = NULL,bool (*copyLine)(unsigned char *) = NULL); // True =  TV Out
	void drawPixel(short x, short y);
	void drawHLine(short x, short y, int l);
	void drawVLine(short x, short y, int l);
	void setColor(unsigned char r, unsigned char g, unsigned char b);
	void setPaletteIndex(unsigned char index);
	void setBackColor(unsigned char r, unsigned char g, unsigned char b);
	unsigned char getRGB323paletteIndex(unsigned char r, unsigned char g, unsigned char b);
	void fillScr(unsigned char index);
	void fillScr(unsigned char r, unsigned char g, unsigned char b);
	void updatePalette(unsigned char index, unsigned char r, unsigned char g, unsigned char b);
	void updatePalette(unsigned char index, unsigned short val);
	void generateRGB323palette();
	//void draw8bBitMap(short x, short y, const unsigned char * dataArray, bool useSkipBit, flipOption flipOpt = noflip);
	void drawCompressed24bitBitmap(short x, short y, const unsigned int * dataArray);
	unsigned char getIndex(short x, short y);
	void swapFrameBuffers();
	void dmaI2S();
	unsigned char * getLineBufferAddress(unsigned short Y);
	bool flushFB();
	float getFPS();
	void writeCMD(unsigned char cmd);
	void writeDATA(unsigned data);
};
#endif